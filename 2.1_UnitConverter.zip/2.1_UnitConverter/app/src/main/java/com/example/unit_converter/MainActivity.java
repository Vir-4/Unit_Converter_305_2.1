package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageB imageB1,imageB2,imageB3; TextView textV1,textV2,textV3;
    EditText input;
    float number, v1,v2,v3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);

        textV1 = findViewById(R.id.textV1);
        textV2 = findViewById(R.id.textV2);
        textV3 = findViewById(R.id.textV3);
        input = findViewById(R.id.input);

        imageB1 = findViewById(R.id.imageB1);
        imageB2 = findViewById(R.id.imageB2);
        imageB3 = findViewById(R.id.image3);

        imageB1.setOnClickL(new View.OnClickL() {
            @Override
            public void onClick(View v) {
                if (spinner.getSelectedItem().toString().equals("Meter") )
                {
                    number = Float.parseFloat(input.getText().toString());

                    v1 = 100*number;
                    v2 = (float) ((3.28)*number);
                    v3 = (float) ((39.37)*number);
                    textV1.setText( (String.format("%.2f", v1))+ " Centimetre");textV2.setText( (String.format("%.2f", v2))+ " Foot");
                    textV3.setText( (String.format("%.2f", v3))+ " Inch");
                }

                else
                {
                    textV1.setText("");textV2.setText("");textV3.setText("");
                    Toast.makeText( MainActivity.this ,  "Please select the Correct Option",Toast.LENGTH_LONG).show();
                }
            }
        });
        imageB3.setOnClickL(new View.OnClickL() {
            @Override
            public void onClick(View v) {

                if (spinner.getSelectedItem().toString().equals("Kilogram"))
                {
                    number = Float.parseFloat(input.getText().toString());
                    v1 = 1000*number;
                    v1 = (float) ((2.20)*number);
                    v1 = (float) ((35.27)*number);

                    textV1.setText( (String.format("%.2f", v1)) + " Grams");textV2.setText( (String.format("%.2f", v1)) + " Ounces");
                    textV3.setText( (String.format("%.2f", v1)) + " Pounds");
                }

                else
                {
                    textV1.setText("");textV2.setText("");textV3.setText("");
                    Toast.makeText( MainActivity.this ,  "Please select the correct option",Toast.LENGTH_LONG).show();

                }
            }
        });
        imageB2.setOnClickL(new View.OnClickL() {
            @Override
            public void onClick(View v) {

                if (spinner.getSelectedItem().toString().equals("Celsius"))
                {
                    number = Float.parseFloat(input.getText().toString());
                    v2 = (float)(number + 273.15);
                    v1 = (float)(9*number)/5 +32;
                    textV1.setText( (String.format("%.2f", v1))+ " Fahrenheight");textV2.setText( (String.format("%.2f", v2)) + " Kelvin");
                    textV3.setText("");
                }

                else
                {
                    textV1.setText("");textV2.setText("");textV3.setText("");
                    Toast.makeText( MainActivity.this ,  "Please select the correct option",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}